  for f in *.zip_dir ; do 
  	cd $f
  done
