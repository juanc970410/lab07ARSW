node horseman.js u1 a 500 3000 &
node horseman.js u2 p 1000 500 &
wait
echo done!
